<nav class="navbar navbar-inverse" role="navigation">
    <ul class="nav navbar-nav">
        <li  class="dropdown">
            <a class="dropdown-toggle" data-toggle="dropdown" href="#">Admin Management<span class="caret"></span></a>
            <ul class="dropdown-menu">
                <li><a href="{{url('/Contents')}}">Contants</a></li>
                <li><a href="{{url('/ServiceTypes')}}">Service</a></li>
                <li><a href="{{url('/Properties')}}">Property</a></li>
                <li><a href="{{url('/Texts')}}">Text</a></li>
                <li><a href="{{url('/Customers')}}">Customer</a></li>
                <li><a href="{{url('/Sites')}}">Sites</a></li>
            </ul>
        </li>	
    </ul>
</nav>