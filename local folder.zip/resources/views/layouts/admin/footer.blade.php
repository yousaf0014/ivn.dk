<div class="footer">
    <div class="pull-right">
        Admin View
    </div>
    <div>
        <strong>Copyright</strong> IVN.dk &copy; 2014-2017
    </div>
</div>
