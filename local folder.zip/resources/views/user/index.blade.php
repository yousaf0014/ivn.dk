@extends('layouts.default.app')
<!-- if there are creation errors, they will show here -->
@section('content')
@endsection
@section('scripts')
    
@endsection