<body>
	<table cellpadding="10" cellspacing="0">
		<tr>
			<td>{{date('m/d/Y')}}</td>
			<td>
				<div style="float:right"><img src="{{ asset('images/img-ivn-contact-us.jpg') }}"></div>
				<div style="clear:both"></div>
			</td>
		</tr>
		<tr>
			<td colspan="2">
				<p>Velkommen til IVN</p>
				<p>Du er nu medlem af IVN.dk, </p>
				<p>Det vil vi gerne fejre med at give dig en rabatkode til 250 styk visitkort fra Lasertryk.</p>
				<p>Du skal bruge koden: UIVVISIT18 når du opretter ordren på www.lasertryk.dk.</p>
				<p>Det eneste du skal betale er fragt.</p>
				<p>Vi vil være Iværksætternes foretrukne portal, og derfor har vi brug for din hjælp. </p>
				<p>Har du gode råd eller idéer til, hvordan vi forbedrer IVN.dk, så send dem til os på info@ivn.dk.</p>
				<p>God fornøjelse.</p>
				<br/>
				<br/>
				<p>Med venlig hilsen / Best regards</p>
				<h4>IVN<h4>
			</td>
		</tr>
	</table>
</body>