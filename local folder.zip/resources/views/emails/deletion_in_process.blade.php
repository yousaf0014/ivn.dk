<body>
	<table cellpadding="10" cellspacing="0">
		<tr>
			<td>{{date('m/d/Y')}}</td>
			<td>
				<div style="float:right"><img src="{{ asset('images/img-ivn-contact-us.jpg') }}"></div>
				<div style="clear:both"></div>
			</td>
		</tr>
		<tr>
			<td colspan="2">
				<p>Din bruger på IVN er blevet deaktiveret, og vil nu blive slettet.</p>
				<br/>
				<p>Har du ikke bedt om at få din profil slettet, skal du kontakte os på info@ivn.dk. Så kan vi genaktivere din konto.</p>
				<br/>
				<p>Vi håber, at du vender tilbage.</p>
				<br/>
				<br/>
				<p>Mvh</p>
				<h4>IVN<h4>		
			</td>
		</tr>
	</table>
</body>