<body>
	<table cellpadding="10" cellspacing="0">
		<tr>
			<td>{{date('m/d/Y')}}</td>
			<td>
				<div style="float:right"><img src="{{ asset('images/img-ivn-contact-us.jpg') }}"></div>
				<div style="clear:both"></div>
			</td>
		</tr>
		<tr>
			<td colspan="2"><b>Få rabat på advokatbistand.</b></td>
		</tr>
		<tr>
			<td colspan="2">Hermed din kode til brug på glitnr.com</td>
		</tr>
		<tr>
			<td colspan="2" style="padding-left:100px;"><?php echo cmskey('glitnr_email_code',true); ?></td>
		</tr>

		<tr>
			<td colspan="2" >Klik her for at gå direkte til glitnrs side:</td>
		</tr>
		<tr>
			<td colspan="2"><a style="background-color: #b8d7eb; padding: 10px 15px; border-radius: 5px; color: #333; font-size: 16px; text-decoration: none;" href="https://glitnr.com" target="_blank">glitnr.com</a>
			</td>
		</tr>
		<tr>
			<td colspan="2"><br />God fornøjelse</td> 
		</tr>
		<tr>
			<td colspan="2"><br /><br /><b>IVN</b></td> 
		</tr>
	</table>
</body>