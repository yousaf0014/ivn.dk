<body>
	<table cellpadding="10" cellspacing="0">
		<tr>
			<td>{{date('m/d/Y')}}</td>
			<td>
				<div style="float:right"><img src="{{ asset('images/img-ivn-contact-us.jpg') }}"></div>
				<div style="clear:both"></div>
			</td>
		</tr>
		<tr>
			<td colspan="2">
				<p>Vi har nu slettet din profil på IVN.dk</p>
				<br/>
				<br/>
				<p>Mvh</p>
				<h4>IVN<h4>
			</td>
		</tr>
	</table>
</body>