<?php

return [
    'subscribe' => 'Du vil modtage vores nyhedsbrev på :email',
    'unsubscribe' => 'Du vil ikke længere modtage vores nyhedsbrev på :email',
];
